import React, { useState, useEffect } from "react";
import { PageHeader } from "../components/PageHeader";
import { Search, Filter, RefreshCw, AlertCircle, X, Terminal, Copy, Check } from "lucide-react";
import { api } from "../api";

function relativeTime(isoString) {
  if (!isoString) return "Never";
  const then = new Date(isoString).getTime();
  const diffSec = Math.floor((Date.now() - then) / 1000);
  if (diffSec < 5) return "Just now";
  if (diffSec < 60) return `${diffSec}s ago`;
  const diffMin = Math.floor(diffSec / 60);
  if (diffMin < 60) return `${diffMin}m ago`;
  const diffHr = Math.floor(diffMin / 60);
  if (diffHr < 24) return `${diffHr}h ago`;
  return `${Math.floor(diffHr / 24)}d ago`;
}

function getSeverityBadge(severityId) {
  switch (severityId) {
    case 5:
    case 6:
      return <span className="px-2 py-0.5 rounded bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-mono">Critical</span>;
    case 4:
      return <span className="px-2 py-0.5 rounded bg-orange-500/20 text-orange-300 border border-orange-500/30 text-xs font-mono">High</span>;
    case 3:
      return <span className="px-2 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-mono">Medium</span>;
    case 2:
      return <span className="px-2 py-0.5 rounded bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-mono">Low</span>;
    default:
      return <span className="px-2 py-0.5 rounded bg-slate-800 text-slate-400 border border-slate-700 text-xs font-mono">Info</span>;
  }
}

export const Events = () => {
  const [events, setEvents] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [filterOS, setFilterOS] = useState("all");
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedEvent, setSelectedEvent] = useState(null);
  const [copied, setCopied] = useState(false);

  const loadEvents = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await api.listEvents({ limit: 100 });
      const items = res?.items ? res.items : (Array.isArray(res) ? res : []);
      setEvents(items);
    } catch (err) {
      setError(err.message || "Failed to load telemetry events");
      setEvents([]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEvents();
  }, []);

  const handleCopy = () => {
    if (!selectedEvent) return;
    navigator.clipboard.writeText(JSON.stringify(selectedEvent, null, 2));
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const filteredEvents = events.filter((ev) => {
    const matchesOS = filterOS === "all" || ev.host_os?.toLowerCase() === filterOS.toLowerCase();
    const searchTarget = `${ev.hostname || ""} ${ev.type_uid || ""} ${ev.username || ""} ${JSON.stringify(ev.data || {})}`.toLowerCase();
    const matchesSearch = searchTarget.includes(searchTerm.toLowerCase());
    return matchesOS && matchesSearch;
  });

  return (
    <div>
      <PageHeader
        title="Live Telemetry Stream"
        description="Raw OCSF telemetry ingested via persistent WebSocket connections."
        action={
          <button
            onClick={loadEvents}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition-colors"
            title="Refresh Events"
          >
            <RefreshCw className={`h-4 w-4 ${loading ? "animate-spin" : ""}`} />
          </button>
        }
      />

      {error && (
        <div className="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-sm flex items-center gap-2">
          <AlertCircle className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}

      <div className="flex flex-col md:flex-row items-center justify-between gap-4 mb-6">
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search host, user, UID, or JSON payload..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-800 rounded-xl pl-10 pr-4 py-2 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 transition-colors"
          />
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Filter className="h-4 w-4 text-slate-400" />
          <span className="text-xs text-slate-400 font-medium">OS:</span>
          {["all", "windows", "linux"].map((os) => (
            <button
              key={os}
              onClick={() => setFilterOS(os)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium capitalize transition-colors ${
                filterOS === os
                  ? "bg-indigo-600 text-white"
                  : "bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200"
              }`}
            >
              {os}
            </button>
          ))}
        </div>
      </div>

      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl overflow-hidden backdrop-blur-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-950/40 text-xs font-medium text-slate-400 uppercase tracking-wider">
                <th className="py-3.5 px-6">Event Time (UTC)</th>
                <th className="py-3.5 px-6">Host / User</th>
                <th className="py-3.5 px-6">Severity</th>
                <th className="py-3.5 px-6">Type UID</th>
                <th className="py-3.5 px-6">Data (OCSF)</th>
                <th className="py-3.5 px-6">Source</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/80 text-sm text-slate-300">
              {filteredEvents.length === 0 && !loading ? (
                <tr>
                  <td colSpan="6" className="py-8 text-center text-slate-500 text-sm">
                    No telemetry events found in the database.
                  </td>
                </tr>
              ) : (
                filteredEvents.map((ev) => (
                  <tr
                    key={ev.event_id}
                    onClick={() => setSelectedEvent(ev)}
                    className="hover:bg-slate-800/50 transition-colors cursor-pointer"
                  >
                    <td className="py-4 px-6 font-mono text-xs text-slate-400">
                      {ev.time ? new Date(ev.time).toLocaleString() : "—"}
                      <span className="block text-[11px] text-slate-500">{relativeTime(ev.time)}</span>
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-semibold text-slate-100">{ev.hostname || "unknown"}</span>
                      <span className="block text-[10px] text-slate-400 uppercase font-mono">
                        {ev.host_os || "node"} {ev.username ? `• ${ev.username}` : ""}
                      </span>
                    </td>
                    <td className="py-4 px-6">
                      {getSeverityBadge(ev.severity_id)}
                    </td>
                    <td className="py-4 px-6">
                      <span className="font-mono text-xs text-indigo-300 bg-indigo-500/10 border border-indigo-500/20 px-2 py-0.5 rounded">
                        {ev.type_uid}
                      </span>
                    </td>
                    <td className="py-4 px-6 font-mono text-xs text-slate-300 max-w-sm truncate" title={JSON.stringify(ev.data)}>
                      {typeof ev.data === "object" ? JSON.stringify(ev.data) : ev.data}
                    </td>
                    <td className="py-4 px-6">
                      <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-mono">
                        {ev.ingest_source || "websocket"}
                      </span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Inspector Modal */}
      {selectedEvent && (
        <div className="fixed inset-0 z-50 flex justify-end bg-slate-950/70 backdrop-blur-sm">
          <div className="w-full max-w-2xl bg-slate-900 border-l border-slate-800 h-full overflow-y-auto shadow-2xl p-6 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400">
                    <Terminal className="h-5 w-5" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-slate-100">Telemetry Event Details</h3>
                    <span className="text-xs font-mono text-slate-400 truncate max-w-xs block">
                      {selectedEvent.event_id}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => setSelectedEvent(null)}
                  className="p-1.5 rounded-lg text-slate-400 hover:text-slate-200 hover:bg-slate-800"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>

              <div className="grid grid-cols-2 gap-4 my-6">
                <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">Time (UTC)</span>
                  <span className="text-xs font-mono text-slate-200">
                    {new Date(selectedEvent.time).toUTCString()}
                  </span>
                </div>

                <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">Severity & Class</span>
                  <div className="flex items-center gap-2">
                    {getSeverityBadge(selectedEvent.severity_id)}
                    <span className="text-xs font-mono text-slate-300">Class: {selectedEvent.class_uid}</span>
                  </div>
                </div>

                <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">Host & System</span>
                  <span className="text-xs font-semibold text-slate-200 block">
                    {selectedEvent.hostname} ({selectedEvent.host_os || 'OS'})
                  </span>
                  <span className="text-[10px] text-slate-400 font-mono">User: {selectedEvent.username || 'SYSTEM'}</span>
                </div>

                <div className="bg-slate-950/60 border border-slate-800/80 p-3.5 rounded-xl">
                  <span className="text-[11px] font-medium text-slate-400 uppercase tracking-wider block mb-1">Pipeline</span>
                  <span className="text-xs font-mono text-emerald-400 uppercase">
                    {selectedEvent.ingest_source || 'websocket'}
                  </span>
                  <span className="text-[10px] text-slate-400 block font-mono">Agent ID: {selectedEvent.agent_id}</span>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-slate-300 uppercase tracking-wider">
                    OCSF Data Fields (`data` JSONB)
                  </span>
                  <button
                    onClick={handleCopy}
                    className="flex items-center gap-1.5 px-3 py-1 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs transition-colors"
                  >
                    {copied ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Copy className="h-3.5 w-3.5" />}
                    {copied ? 'Copied' : 'Copy JSON'}
                  </button>
                </div>

                <pre className="bg-slate-950 border border-slate-800 p-4 rounded-xl text-xs font-mono text-indigo-300 overflow-x-auto whitespace-pre-wrap max-h-[380px]">
                  {JSON.stringify(selectedEvent.data, null, 2)}
                </pre>
              </div>
            </div>

            <div className="pt-4 border-t border-slate-800 flex justify-end">
              <button
                onClick={() => setSelectedEvent(null)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-medium"
              >
                Close Inspector
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};