import React, { useState, useEffect } from "react";
import { X, Copy, Check, Key, ShieldAlert, Terminal, Monitor } from "lucide-react";
import { api, API_URL } from "../api";

export const GenerateTokenModal = ({ isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [osType, setOsType] = useState("windows");
  const [tokenData, setTokenData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (isOpen) {
      fetchNewToken();
    }
  }, [isOpen]);

  const fetchNewToken = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.generateToken();
      setTokenData(data);
    } catch (err) {
      setError(err.message || "Failed to generate token");
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  const currentToken = tokenData?.token || "";
  const serverHost = API_URL.replace(/^https?:\/\//, "");

  const downloadCommand =
    osType === "windows"
      ? `powershell -Command "Invoke-WebRequest -Uri '${API_URL}/downloads/edr-agent.exe' -OutFile 'edr-agent.exe'"`
      : `curl -SL ${API_URL}/downloads/edr-agent -o edr-agent && chmod +x edr-agent`;

  const runCommand =
    osType === "windows"
      ? `.\\edr-agent.exe --server=${API_URL} --token=${currentToken}`
      : `sudo ./edr-agent --server=${API_URL} --token=${currentToken}`;

  const fullInstallationScript = `${downloadCommand}\n${runCommand}`;

  const handleCopy = () => {
    navigator.clipboard.writeText(fullInstallationScript);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm p-4">
      <div className="bg-slate-900 border border-slate-800 rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-6 py-4 border-b border-slate-800">
          <div className="flex items-center gap-3">
            <div className="h-9 w-9 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Key className="h-5 w-5" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-slate-100">Enrollment Token & Agent Installer</h3>
              <p className="text-xs text-slate-400">Single-use token valid for 1 hour</p>
            </div>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-slate-200 p-1 rounded-lg hover:bg-slate-800">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-6 space-y-5">
          {error && (
            <div className="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-rose-400 text-xs">
              {error}
            </div>
          )}

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-2 uppercase tracking-wider">
              Target Operating System
            </label>
            <div className="grid grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setOsType("windows")}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-medium transition-all ${
                  osType === "windows"
                    ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-lg shadow-indigo-500/10"
                    : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40"
                }`}
              >
                <Monitor className="h-4 w-4" />
                Windows (.exe)
              </button>
              <button
                type="button"
                onClick={() => setOsType("linux")}
                className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-medium transition-all ${
                  osType === "linux"
                    ? "bg-indigo-600/20 border-indigo-500 text-indigo-300 shadow-lg shadow-indigo-500/10"
                    : "bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40"
                }`}
              >
                <Terminal className="h-4 w-4" />
                Linux / Kali Node
              </button>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-medium text-slate-400 uppercase tracking-wider">
                Enrollment Secret
              </label>
              <button
                onClick={fetchNewToken}
                disabled={loading}
                className="text-xs text-indigo-400 hover:text-indigo-300 underline"
              >
                {loading ? "Generating..." : "Generate New Token"}
              </button>
            </div>
            <input
              type="text"
              readOnly
              value={currentToken}
              placeholder="Generating token from backend..."
              className="w-full bg-slate-900 border border-slate-700/80 rounded-lg px-3.5 py-2 text-sm font-mono text-indigo-300 focus:outline-none select-all"
            />
          </div>

          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-medium text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
                <Terminal className="h-3.5 w-3.5 text-indigo-400" />
                Commands ({osType})
              </span>
              <button
                onClick={handleCopy}
                disabled={!currentToken}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 text-white rounded-lg text-xs font-medium transition-colors"
              >
                {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                {copied ? "Copied" : "Copy Commands"}
              </button>
            </div>
            <pre className="bg-slate-900 border border-slate-800 rounded-lg p-3 text-xs font-mono text-emerald-400 overflow-x-auto whitespace-pre-wrap select-all">
              {downloadCommand}
              {"\n"}
              {runCommand}
            </pre>
          </div>

          <div className="pt-2 flex items-center justify-end border-t border-slate-800">
            <button
              onClick={onClose}
              className="px-5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-sm font-medium transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};